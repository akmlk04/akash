# Ludo Royale — Android APK Project Guide

This package contains the complete Android application source project for **Ludo Royale** (a Ludo King–style board game with 2–4 player Pass & Play, Smart AI Bots, Classic 4-Token & Quick Rush 2-Token modes, safe star squares, captures, bonus rolls, and synthesized sound effects).

## Option 1: Build APK in Android Studio (Local)
1. Extract `ludo_royale_android_apk_project.zip`.
2. Open **Android Studio** and select **Open** -> choose the extracted folder.
3. Let Gradle sync automatically, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)** from the top menu.
4. Your installable `.apk` file will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`

## Option 2: Build APK in the Cloud with GitHub Actions (No Local Install Required)
1. Create a new repository on GitHub and upload the extracted files (making sure `.github/workflows/build-apk.yml` is included).
2. Open the **Actions** tab in your GitHub repository and run **Build Ludo Royale Android APK**.
3. Download the compiled `ludo-royale-debug-apk` artifact directly to your Android phone and install it.
